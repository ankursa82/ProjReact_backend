import App from './App.jsx'
import { StrictMode, lazy, Suspense } from 'react'
import { createRoot } from 'react-dom/client'
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import appStore from './utils/appStore.js';
const Prodlist=lazy(()=> import("./components/ProductList.jsx"));
const ProdDetail=lazy (()=>import('./components/ProdDetail.jsx'));
const Cart=lazy(()=>import('./components/Cart.jsx'));
const Error=lazy(()=>import('./components/Error.jsx'));
const appRouter=createBrowserRouter([
  {
  path:"/",
  element:<App/>,
  errorElement:<Error/>,
  children:[
    {
      path:"/",
      element:<Suspense fallback={<div>Loading...</div>}><Prodlist/></Suspense>    
    },
    {
      path:"/list/:id",
      element:<Suspense fallback={<div>Loading...</div>}><ProdDetail/></Suspense>
    },
    {
      path:"/cart",
      element:<Suspense fallback={<div>Loading...</div>}><Cart/></Suspense>
    },
    {
      path:"*",
      element:<Suspense fallback={<div>Loading...</div>}><Error/></Suspense>
    }
]}
]);
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Provider store={appStore}>
    <RouterProvider router={appRouter} />
    </Provider>
  </StrictMode>
)
