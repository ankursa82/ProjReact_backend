import { useSelector } from "react-redux";
import CartItem from "./CartItem";
export default function Cart(){
    const products=useSelector(store=>store.cart);
    return(
        <>
        {
            products.map(product=>{
                return<CartItem key={product.id} product={product}/>;
            })
        }
        </>
    )
}