import "../App.css"
import { Link } from "react-router-dom";
import {useDispatch} from "react-redux";
import {addToCart} from "../utils/cartSlice"
function ProdItem({product}){
    const dispatch = useDispatch();
    return(
        <>
                <div className="container">
                <div className="prod-item">
                <Link to={`/list/${product.id}`}><h2>{product.title}</h2></Link>
                <button onClick={()=>dispatch(addToCart(product))}>Add to Cart</button>
                </div>
                </div>
        </>
    )
}
export default ProdItem;