function Error({error}){
    return(
        
        <div style={{textAlign: "center"}}>
        <h1>"Oops!! Please enter correct path"</h1>
        <img src="https://i.pinimg.com/originals/db/30/66/db3066ae6bd9bbfc54374870640b9dc0.gif" width="200px" height="200px"/>
        <h2>{error}</h2>
        </div>
      
        
    )
}
export default Error;