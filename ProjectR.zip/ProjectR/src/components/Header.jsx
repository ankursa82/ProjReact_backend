import { Link } from "react-router-dom";
import "../App.css"
import { useSelector } from "react-redux"
export default function Header(){
    const cartItems= useSelector(store=> store.cart);
    return(
        <>
        <div className="nav">
        <h1>Welcome to ShoppyGlobe Products page..</h1>
        <Link to="/"><span style={{position:"absolute", left:0}}>ShoppyGlobe</span></Link>|
        <Link to ="/cart"><span style={{position:"absolute",right:"0"}}>🛒{cartItems.length} items</span></Link>
        </div>
        </>
    )
}