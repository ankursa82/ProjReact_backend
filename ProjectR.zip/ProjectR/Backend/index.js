import express from "express";
import mongoose from "mongoose";
import router1 from "./routes/authRoutes.js";
import router2 from "./routes/productRoutes.js";
import router3 from "./routes/cartRoutes.js";
const app = express();
app.use(express.json());

const MONGO_URI = "mongodb://localhost:27017/shoppyglobe";
mongoose.connect(MONGO_URI)
.then(()=>console.log("✅MongoDB connected"))
.catch((err)=>console.error("❌ DB Error:", err));

app.use("/",router1);
app.use("/products",router2);
app.use("/cart", router3);

const PORT = 3000;
app.listen(PORT, ()=>{
   console.log(`Server running on http://localhost:${PORT}`);
});

