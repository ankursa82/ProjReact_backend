import Cart from "../models/cart.js";
import Product from "../models/product.js";

export const addToCart = async(req,res)=>{
    const {productId, quantity}= req.body;
    const userId = req.user.userId;
    try{
        const product = await Product.findById(productId);
        if(!product) return res.status(404).json({message:"Product not found"});
        let cart = await Cart.findOne({userId});
        if(!cart){
            cart = new Cart({userId,items:[{productId,quantity}]});
        }else{
            const item = cart.items.find(item=>item.productId.equals(productId));
            if(item){
                item.quantity+=quantity;
            }else{
                cart.items.push({productId,quantity});
            }
        }
        await cart.save();
        res.json({message: "Items added to cart"});
    }catch(err){
        res.status(500).json({message:"Error adding to cart"});
    }
}

export const fetchCart = async(req,res)=>{
    
    try{
        const products = await Cart.find();
        if(!products)
        return res.status(404).json({message:"Products not found"});
        res.send(products);
    }catch(e){
        res.status(500).json({message:"Error fetching products"});
    }
}
export const fetchCartById=async(req,res)=>{
    const productId= req.params.productId;
    const userId= req.user.userId;
    try{
        const cart = await Cart.findOne({userId});
        if(!cart) return res.status(404).json({message:"Cart not found"});

        const item= cart.items.find(item=>item.productId.equals(productId));
        if(!item) return res.status(404).json({message:"Item not in cart"});
       
        res.json({quantity:item.quantity,
            productId:item.productId
        });
    }catch(err){
        res.status(500).json({message:"Error updating cart"})
    }
}

export const updateCartItem = async (req, res)=>{
    const {quantity}= req.body;
    const userId= req.user.userId;
    const productId = req.params.productId;

    try{
        const cart = await Cart.findOne({userId});
        if(!cart) return res.status(404).json({message:"Cart not found"});

        const item= cart.items.find(item=>item.productId.equals(productId));
        if(!item) return res.status(404).json({message:"Item not in cart"});
        item.quantity = quantity;
        await cart.save();
        res.json({message:"Cart updated"});
    }catch(err){
        res.status(500).json({message:"Error updating cart"})
    }
};

export const removeCartItem = async(req,res)=>{
    const userId = req.user.userId;
    const productId = req.params.productId;
    try{
        const cart = await Cart.findOne({userId});
        if(!cart) return res.status(404).json({message:"Cart not found"});

        cart.items= cart.items.filter(item=>!item.productId.equals(productId));
        await cart.save();
        res.json({message: "Items removed from cart"});
    }catch(err){
        res.status(500).json({message:"Error removing from cart"});
    }
};