import Product from "../models/product.js";
export const getAllProducts = async(req,res)=>{
    try{
        const products = await Product.find();
        res.send(products);
    }catch(err){
        res.status(500).json({message:"Error fetching products"});
    }
};
export const getProductById = async(req,res)=>{
    try{
        const product = await Product.findById(req.params.id);
        if(!product)
        return res.status(404).json({message:"Product not found"});
        res.send(product);
    }catch(e){
        res.status(500).json({message:"Error fetching product"});
    }
};
// mongodb+srv://ec022434:6BB8lausXGvRtL0N@cluster82.c9makv4.mongodb.net/