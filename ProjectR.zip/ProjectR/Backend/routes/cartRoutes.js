import express from "express";
import {addToCart, fetchCart, updateCartItem, removeCartItem, fetchCartById} from "../controllers/cartController.js";
import {authenticate} from "../middleware/auth.js";

const router = express.Router();
router.get("/",authenticate,fetchCart);
router.get("/:productId",authenticate,fetchCartById);
router.post("/",authenticate,addToCart);
router.put("/:productId", authenticate, updateCartItem);
router.delete("/:productId",authenticate, removeCartItem);
export default router;