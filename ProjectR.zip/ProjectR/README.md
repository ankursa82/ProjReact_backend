
Project Repository path: https://github.com/ankursa82/ProjReact_backend

Open the zip folder ProjectR.zip in main branch.

Save it in your laptop. Install node modules. Run the project.

Readme.md file path: https://github.com/ankursa82/ProjReact_backend/blob/main/README.md

Also install react-router-dom, react-redux, @reduxjs/toolkit.
Also install express, mongoose and jsonwebtoken.